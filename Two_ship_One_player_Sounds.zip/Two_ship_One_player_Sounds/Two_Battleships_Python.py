from random import randint
import winsound

#8x8 board:
board = []
for row in range(8):
    board.append(["O"] * 8)

#Intro:
def print_board(board):
    for row in board:
        print " ".join(row)

print "Let's Play Battleship!"
print_board(board)
winsound.PlaySound('battle001.wav',winsound.SND_FILENAME)
print "Guess from 1 to 8 for row and column."

#Battleship has 4 spaces. Can be horizontal or vertical.
b_orientation = randint(0,1)
b_rows = []
b_cols = []
if b_orientation == 0: #Horizontal
    #initialize rows (just 1 row):
    b_row = randint(0,7)
    for i in range(4):
        b_rows.append(b_row)
    #initialize cols:
    b_start_col = randint(0,4)
    for i in range(4):
        b_cols.append(b_start_col + i)
else: #Vertical
    #initialize rows:
    b_start_row = randint(0,4)
    for i in range(4):
        b_rows.append(b_start_row + i)
    #initialize cols (just 1 col):
    b_col = randint(0,7)
    for i in range(4):
        b_cols.append(b_col)
#print "Battleship rows: ", b_rows
#print "Battleship cols: ", b_cols
#if b_orientation == 0: #Battleship is horizontal
    #print "Battleship orientation: ", b_orientation, " Horizontal"
#else: #Battleship is vertical
    #print "Battleship orientation: ", b_orientation, " Vertical"
b_hits = 0 #Number of hits the battleship has taken

#Destroyer has 3 spaces. Can be horizontal or vertical.
d_rows = []
d_cols = []
d_orientation = randint(0,1)
while d_orientation == 0 or d_orientation == 1:
    if d_orientation == 0:
        #initialize rows (just 1 row):
        d_row = randint(0,7)
        for i in range(3):
            d_rows.append(d_row)
        #initialize cols:
        d_start_col = randint(0,5)
        for i in range(3):
            d_cols.append(d_start_col + i)
    else:
        #initialize rows:
        d_start_row = randint(0,5)
        for i in range(3):
            d_rows.append(d_start_row + i)
        #initialize cols (just 1 col):
        d_col = randint(0,7)
        for i in range(3):
            d_cols.append(d_col)
    for (row, col) in zip(d_rows, d_cols):
        if (row, col) in zip(b_rows, b_cols): #if combo of destroyer row and col is shared with battleship:
            d_rows = []
            d_cols = []
            d_orientation = randint(0,1)
            #print "While loop continuing..."
            break
        #else:
            #print "For loop continuing..."
    else:
        #print "For loop done, while loop exiting..."
        break
#print "Destroyer rows: ", d_rows
#print "Destroyer cols: ", d_cols
#if d_orientation == 0:
    #print "Destroyer orientation: ", d_orientation, " Horizontal"
#else:
    #print "Destroyer orientation: ", d_orientation, " Vertical"

d_hits = 0 #Number of hits the destroyer has taken

def acceptable_guess(guess):
    if guess == "" or guess not in "1234567890":
        print "Oops, that's not an integer"
        return False
    else:
        return True
        
winning_statement = "Enemy fleet destroyed. Congratulations admiral, you won!!! :D"

def losing_statement():
    print "Game Over!"
    winsound.PlaySound('game_over.wav',winsound.SND_FILENAME)
    print "Battleship Rows: ", [x+1 for x in b_rows]
    print "Battleship Cols: ", [x+1 for x in b_cols]
    print "Destroyer Rows: ", [x+1 for x in d_rows]
    print "Destroyer Cols: ", [x+1 for x in d_cols]
    for i,j in zip(b_rows,b_cols):
        if board[i][j] != "X":
            board[i][j] = "B"
    for i,j in zip(d_rows,d_cols):
        if board[i][j] != "X":
            board[i][j] = "D"
    print_board(board)

for turn in range(25):
    print "Turn", (turn + 1)
    quit = False
    acceptable_row = False
    acceptable_col = False
    guess_row = None
    guess_col = None
    while acceptable_row == False:
        guess_row = raw_input("Guess Row: ")
        if (guess_row.lower() == "q" or guess_row.lower() == "quit" or guess_row.lower() == "exit"):
            quit = True
            break            
        acceptable_row = acceptable_guess(guess_row)
    if quit == True:
        break
    guess_row = int(guess_row)
    while acceptable_col == False:
        guess_col = raw_input("Guess Col: ")
        if (guess_col.lower() == "q" or guess_col.lower() == "quit" or guess_col.lower() == "exit"):
            quit = True
            break 
        acceptable_col = acceptable_guess(guess_col)
    if quit == True:
        break
    guess_col = int(guess_col)
    winsound.PlaySound('cannon.wav',winsound.SND_FILENAME)
    if guess_row - 1 in b_rows and guess_col - 1 in b_cols and board[guess_row - 1][guess_col - 1] != "X":
        board[guess_row - 1][guess_col - 1] = "X"
        print_board(board)
        winsound.PlaySound('GE_Explosion.wav',winsound.SND_FILENAME)
        print "You hit!"
        b_hits += 1
        if b_hits == 4:
            winsound.PlaySound('trumpets_fanfare',winsound.SND_FILENAME)
            print "Congratulations! You sunk my battleship!"
            if d_hits == 3:
                print winning_statement
                winsound.PlaySound('fanfare3.wav',winsound.SND_FILENAME)
                break
    elif guess_row - 1 in d_rows and guess_col - 1 in d_cols and board[guess_row - 1][guess_col - 1] != "X":
        board[guess_row - 1][guess_col - 1] = "X"
        print_board(board)
        winsound.PlaySound('GE_Explosion.wav',winsound.SND_FILENAME)
        print "You hit!"
        d_hits += 1
        if d_hits == 3:
            winsound.PlaySound('trumpets_fanfare',winsound.SND_FILENAME)
            print "Congratulations! You sunk my destroyer!"
            if b_hits == 4:
                print winning_statement
                winsound.PlaySound('fanfare3.wav',winsound.SND_FILENAME)
                break
    else:
        if (guess_row < 1 or guess_row > 8) or \
        (guess_col < 1 or guess_col > 8):
            print_board(board)
            print "Oops! That's not even in the ocean!"
        elif board[guess_row - 1][guess_col - 1] != "O":
            print_board(board)
            winsound.PlaySound('bathtubsplash.wav',winsound.SND_FILENAME)
            print "You guessed that already!"
        else:
            board[guess_row - 1][guess_col - 1] = " "
            print_board(board)
            winsound.PlaySound('bathtubsplash.wav',winsound.SND_FILENAME)
            print "You missed!"
if b_hits < 4 or d_hits < 3:
    losing_statement()
