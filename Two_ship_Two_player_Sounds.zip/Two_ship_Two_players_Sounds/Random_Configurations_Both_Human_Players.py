from random import randint
import winsound

#Create 8x8 board:
def create_board(board):
    for row in range(8):
        board.append(["O"] * 8)

#Print 8x8 board:
def print_board(board):
    for row in board:
        print " ".join(row)

#Create battleship configurations for given board:
def create_configuration(b_rows,b_cols,d_rows,d_cols):
    #Battleship has 4 spaces. Can be horizontal or vertical.
    b_orientation = randint(0,1) #Horizontal or vertical
    if b_orientation == 0: #Horizontal
        #initialize rows (just 1 row):
        b_row = randint(0,7)
        for i in range(4):
            b_rows.append(b_row)
        #initialize cols:
        b_start_col = randint(0,4)
        for i in range(4):
            b_cols.append(b_start_col + i)
    else: #Vertical
        #initialize rows:
        b_start_row = randint(0,4)
        for i in range(4):
            b_rows.append(b_start_row + i)
        #initialize cols (just 1 col):
        b_col = randint(0,7)
        for i in range(4):
            b_cols.append(b_col)
    
    #Destroyer has 3 spaces. Can be horizontal or vertical.
    d_orientation = randint(0,1) #Horizontal or vertical
    while True: #run until destroyer and battleship don't overlap
        if d_orientation == 0: #Horizontal
            #initialize rows (just 1 row):
            d_row = randint(0,7)
            for i in range(3):
                d_rows.append(d_row)
            #initialize cols:
            d_start_col = randint(0,5)
            for i in range(3):
                d_cols.append(d_start_col + i)
        else: #Vertical
            #initialize rows:
            d_start_row = randint(0,5)
            for i in range(3):
                d_rows.append(d_start_row + i)
            #initialize cols (just 1 col):
            d_col = randint(0,7)
            for i in range(3):
                d_cols.append(d_col)
        for (row, col) in zip(d_rows, d_cols):
            if (row, col) in zip(b_rows, b_cols): #if combo of destroyer row and col is shared with battleship:
                print "Overlapping:"
                print "Row:", row
                print "Col:", col
                print "D_rows:",d_rows
                print "D_cols:",d_cols
                print "B_rows:",b_rows
                print "B_cols:",b_cols
                for i in range(3):
                    del d_rows[0]
                    del d_cols[0]
                d_orientation = randint(0,1)
                break #continue while loop
            #else:
        else:
            break #destroyer and battleship don't overlap: exit while loop
        print "While loop continuing"
    print "Final ship configurations:"
    print "D_rows:",d_rows
    print "D_cols:",d_cols
    print "B_rows:",b_rows
    print "B_cols:",b_cols
#Returns whether or not a player's guess is an acceptable number
def acceptable_guess(guess):
    if guess == "" or guess not in "1234567890":
        print "Oops, that's not an acceptable number"
        return False
    else:
        return True
        
def turn(player,board,b_rows,b_cols,d_rows,d_cols,b_hits,d_hits):
    q = False #Quit
    acceptable_row = False
    acceptable_col = False
    guess_row = None
    guess_col = None
    while acceptable_row == False:
        guess_row = raw_input("Guess Row: ")
        if (guess_row.lower() == "q" or guess_row.lower() == "quit" or guess_row.lower() == "exit"):
            q = True
            break            
        acceptable_row = acceptable_guess(guess_row)
    if q == True:
        return False
    guess_row = int(guess_row)
    while acceptable_col == False:
        guess_col = raw_input("Guess Col: ")
        if (guess_col.lower() == "q" or guess_col.lower() == "quit" or guess_col.lower() == "exit"):
            q = True
            break 
        acceptable_col = acceptable_guess(guess_col)
    if q == True:
        return False
    guess_col = int(guess_col)
    winsound.PlaySound('cannon.wav',winsound.SND_FILENAME)
    if guess_row - 1 in b_rows and guess_col - 1 in b_cols and board[guess_row - 1][guess_col - 1] != "X":
        board[guess_row - 1][guess_col - 1] = "X"
        print_board(board)
        winsound.PlaySound('GE_Explosion.wav',winsound.SND_FILENAME)
        print "You hit!"
        b_hits[0] += 1
        if b_hits[0] == 4:
            winsound.PlaySound('trumpets_fanfare',winsound.SND_FILENAME)
            print "Congratulations! You sunk my battleship!"
            if d_hits[0] == 3:
                return True
    elif guess_row - 1 in d_rows and guess_col - 1 in d_cols and board[guess_row - 1][guess_col - 1] != "X":
        board[guess_row - 1][guess_col - 1] = "X"
        print_board(board)
        winsound.PlaySound('GE_Explosion.wav',winsound.SND_FILENAME)
        print "You hit!"
        d_hits[0] += 1
        if d_hits[0] == 3:
            winsound.PlaySound('trumpets_fanfare',winsound.SND_FILENAME)
            print "Congratulations! You sunk my destroyer!"
            if b_hits[0] == 4:
                return True
    else:
        if (guess_row < 1 or guess_row > 8) or \
        (guess_col < 1 or guess_col > 8):
            print_board(board)
            print "Oops! That's not even in the ocean!"
        elif board[guess_row - 1][guess_col - 1] != "O":
            print_board(board)
            winsound.PlaySound('bathtubsplash.wav',winsound.SND_FILENAME)
            print "You guessed that already!"
        else:
            board[guess_row - 1][guess_col - 1] = " "
            print_board(board)
            winsound.PlaySound('bathtubsplash.wav',winsound.SND_FILENAME)
            print "You missed!"

def introduction():
    print "Let's Play Battleship!"
    winsound.PlaySound('battle001.wav',winsound.SND_FILENAME)
    print "Guess from 1 to 8 for row and column."

def won(player):
    print "Enemy fleet destroyed. Congratulations, " + player + ", you won!!! :D"
    winsound.PlaySound('fanfare3.wav',winsound.SND_FILENAME)
    
def lost(player,board,b_rows,b_cols,d_rows,d_cols):
    print "Game Over, " + player + "!"
    winsound.PlaySound('game_over.wav',winsound.SND_FILENAME)
    print "Battleship Rows: ", [x+1 for x in b_rows]
    print "Battleship Cols: ", [x+1 for x in b_cols]
    print "Destroyer Rows: ", [x+1 for x in d_rows]
    print "Destroyer Cols: ", [x+1 for x in d_cols]
    for i,j in zip(b_rows,b_cols):
        if board[i][j] != "X":
            board[i][j] = "B"
    for i,j in zip(d_rows,d_cols):
        if board[i][j] != "X":
            board[i][j] = "D"
    print_board(board)


#Introduce the game:
introduction()

#Create players (1 and 2):
while True:
    player1 = raw_input('Player 1: ')
    if player1 == "":
        print "Oops, try again"
    else:
        break
while True:
    player2 = raw_input('Player 2: ')
    if player2 == "":
        print "Oops, try again"
    else:
        break
    
#Create Player 1 and Player 2 boards:
board1 = []
create_board(board1)
board2 = []
create_board(board2)

#Create configurations:
b_rows1 = []
b_cols1 = []
d_rows1 = []
d_cols1 = []
create_configuration(b_rows1,b_cols1,d_rows1,d_cols1)
print player1 + "'s board configured."
b_rows2 = []
b_cols2 = []
d_rows2 = []
d_cols2 = []
create_configuration(b_rows2,b_cols2,d_rows2,d_cols2)
print player2 + "'s board configured."

#Initialize number of hits:
b_hits1 = [0]
d_hits1 = [0]
b_hits2 = [0]
d_hits2 = [0]

#Initialize winning status:
player1_won = None
player2_won = None

#Initialize whose turn it is (Player 1):
t = 1

#Play game:
while player1_won == None and player2_won == None:
    if t == 1:
        print ""
        print player1,"go:"
        print_board(board2)
        player1_won = turn(player1,board2,b_rows2,b_cols2,d_rows2,d_cols2,b_hits2,d_hits2)
        t = 2
    else:
        print ""
        print player2,"go:"
        print_board(board1)
        player2_won = turn(player2,board1,b_rows1,b_cols1,d_rows1,d_cols1,b_hits1,d_hits1)
        t = 1
if player1_won == True or player2_won == False:
    print ""
    lost(player2,board1,b_rows1,b_cols1,d_rows1,d_cols1)
    print ""
    won(player1)
else:
    print ""
    lost(player1,board2,b_rows2,b_cols2,d_rows2,d_cols2)
    print ""
    won(player2)
