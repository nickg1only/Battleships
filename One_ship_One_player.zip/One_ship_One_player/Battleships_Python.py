from random import randint

#8x8 board:
board = []
for row in range(8):
    board.append(["O"] * 8)

#Intro:
def print_board(board):
    for row in board:
        print " ".join(row)
print "Let's Play Battleship!"
print_board(board)
print "Guess from 1 to 8 for row and column."

#Destroyer has 3 spaces. Can be horizontal or vertical.
d_orientation = randint(0,1)
d_rows = []
d_cols = []
if d_orientation == 0:  #Horizontal
    d_rows.append(randint(0,7))
    d_start_col = randint(0,5)
    for i in range(3):
        d_cols.append(d_start_col + i)
else:                   #Vertical
    d_start_row = randint(0,5)
    for i in range(3):
        d_rows.append(d_start_row + i)
    d_cols.append(randint(0,7))
d_hits = 0 #Number of hits the destroyer has taken

for turn in range(20):
    print "Turn ", (turn + 1)
    guess_row = int(raw_input("Guess Row: "))
    guess_col = int(raw_input("Guess Col: "))

    if guess_row - 1 in d_rows and guess_col - 1 in d_cols:
        board[guess_row - 1][guess_col - 1] = "X"
        print_board(board)
        print "You hit!"
        d_hits += 1
        if d_hits == 3:
            print "Congratulations! You sunk my destroyer!"
            break
    else:
        if (guess_row < 1 or guess_row > 8) or \
        (guess_col < 1 or guess_col > 8):
            print_board(board)
            print "Oops! That's not even in the ocean!"
        elif board[guess_row - 1][guess_col - 1] == " ":
            print_board(board)
            print "You guessed that already!"
        else:
            board[guess_row - 1][guess_col - 1] = " "
            print_board(board)
            print "You missed!"
if d_hits < 3:
    print "Game Over!"
    print "Destroyer Rows: ", [x+1 for x in d_rows]
    print "Destroyer Cols: ", [x+1 for x in d_cols]
            

    